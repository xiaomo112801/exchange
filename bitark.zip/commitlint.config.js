/*
 * @Author: weisheng
 * @Date: 2024-10-29 20:12:08
 * @LastEditTime: 2024-10-29 20:12:20
 * @LastEditors: weisheng
 * @Description:
 * @FilePath: \salary-calculator\commitlint.config.js
 * 记得注释
 */
export default {
  extends: ['@commitlint/config-conventional'],
}
