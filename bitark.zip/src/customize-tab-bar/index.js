// eslint-disable-next-line no-undef
Component({
  data: {},
  methods: {},
})
