<script setup lang="ts">
definePage({
  name: 'recharge',
  style: {
    navigationBarTitleText: '充值',
  },
})
</script>

<template>
  <view class="recharge-page">
    <view class="recharge-page-title">
      <text>充值</text>
    </view>
  </view>
</template>

<style scoped lang="scss">
.recharge-page {
//   padding: 1rem;
}
</style>
